<?php return array('dependencies' => array(), 'version' => '2f03dc39ec58b53d53c8');
